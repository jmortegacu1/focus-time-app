let workTime = 25 * 60;
let breakTime = 5 * 60;
let longBreak = 15 * 60;
let time = workTime;
let timer;
let isRunning = false;

let pomosDone = parseInt(localStorage.getItem('pomosDone')) || 0;
let timeWorked = parseInt(localStorage.getItem('timeWorked')) || 0;

const timerDisplay = document.getElementById('timer');
const startBtn = document.getElementById('start');
const pauseBtn = document.getElementById('pause');
const resetBtn = document.getElementById('reset');
const pomosDoneDisplay = document.getElementById('pomos-done');
const timeWorkedDisplay = document.getElementById('time-worked');

const workInput = document.getElementById('work-min');
const breakInput = document.getElementById('break-min');
const longInput = document.getElementById('long-min');
const soundSelect = document.getElementById('sound-select');

workInput.addEventListener('change', () => {
  workTime = parseInt(workInput.value) * 60;
  time = workTime;
  updateDisplay();
});

breakInput.addEventListener('change', () => {
  breakTime = parseInt(breakInput.value) * 60;
});

longInput.addEventListener('change', () => {
  longBreak = parseInt(longInput.value) * 60;
});

function updateDisplay() {
  let min = Math.floor(time / 60);
  let sec = time % 60;
  timerDisplay.textContent = `${min.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`;
}

function startTimer() {
  if (!isRunning) {
    isRunning = true;
    timer = setInterval(() => {
      if (time > 0) {
        time--;
        updateDisplay();
      } else {
        clearInterval(timer);
        isRunning = false;
        pomosDone++;
        timeWorked += parseInt(workInput.value);
        localStorage.setItem('pomosDone', pomosDone);
        localStorage.setItem('timeWorked', timeWorked);
        pomosDoneDisplay.textContent = pomosDone;
        timeWorkedDisplay.textContent = timeWorked;
        notify('¡Pomodoro terminado!', true);
      }
    }, 1000);
  }
}

function pauseTimer() {
  clearInterval(timer);
  isRunning = false;
}

function resetTimer() {
  clearInterval(timer);
  isRunning = false;
  time = workTime;
  updateDisplay();
}

function notify(message, playSound) {
  if (Notification.permission === 'granted') {
    new Notification(message);
  } else if (Notification.permission !== 'denied') {
    Notification.requestPermission().then(perm => {
      if (perm === 'granted') new Notification(message);
    });
  }
  if (playSound) {
    let soundURL = soundSelect.value === 'beep'
      ? 'https://www.soundjay.com/button/beep-07.wav'
      : 'https://www.soundjay.com/button/beep-10.wav';
    const audio = new Audio(soundURL);
    audio.play();
  }
}

startBtn.onclick = startTimer;
pauseBtn.onclick = pauseTimer;
resetBtn.onclick = resetTimer;

pomosDoneDisplay.textContent = pomosDone;
timeWorkedDisplay.textContent = timeWorked;
updateDisplay();

document.getElementById('toggle-dark').onclick = () => {
  document.body.classList.toggle('dark-mode');
};